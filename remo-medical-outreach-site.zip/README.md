# Remo Medical Outreach Website

This repository contains the static website for Remo Medical Outreach.

## Pages
- Home (`index.html`)
- About (`about.html`)
- Donate (`donate.html`)
- Volunteer (`volunteer.html`)
- Contact (`contact.html`)

## Deployment
Deploy easily with Vercel or Netlify.
